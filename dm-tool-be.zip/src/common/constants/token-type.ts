export enum TokenType {
  ACCESS_TOKEN = 'ACCESS_TOKEN',
}
