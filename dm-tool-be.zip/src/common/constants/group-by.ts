export enum GroupBy {
  PROJECT = 'project',
  MONTH = 'month',
  All = 'all',
}
