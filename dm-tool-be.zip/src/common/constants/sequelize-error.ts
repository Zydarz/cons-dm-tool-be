export enum SequelizeCodeErrs {
  DUPLICATE = 'SequelizeUniqueConstraintError',
}
