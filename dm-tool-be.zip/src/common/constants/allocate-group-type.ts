export enum AllocateGroupType {
  Day = 'day',
  Week = 'week',
  Month = 'month',
}
