export enum ConstantsResouces {
  constantsMM = 20,
  constantsPer = 100,
  totalRes = 100,
}
