export interface IUserAzure {
  displayName: string;
  jobTitle?: string;
  mail: string;
  userPrincipalName: string;
  id: string;
}
