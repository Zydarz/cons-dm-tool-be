export enum CredentialAzureType {
  USER = 'user',
  ADMIN = 'admin',
}
