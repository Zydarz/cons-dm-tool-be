export enum Comparison {
  GREATER = '>',
  GE = '>=',
  EQUAL = '==',
  LESS = '<',
  LE = '<=',
}
