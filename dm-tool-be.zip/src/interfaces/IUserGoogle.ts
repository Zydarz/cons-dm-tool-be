export interface GUser {
  sub: string;
  given_name: string;
  name: string;
  email: string;
  email_verified: boolean;
  locale: string;
  picture: string;
  family_name: string;
}