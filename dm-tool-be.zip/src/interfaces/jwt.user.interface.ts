export interface JwtUserDto {
  oid: string;
  preferred_username: string;
}
