export interface ITranslationDecoratorInterface {
  translationKey: string;
}
