export interface IApiFile {
  name: string;
  isArray?: boolean;
}
