import { PageOptionsDto } from '../../../../common/dto/page-options.dto';

export class ListMasterDataDto extends PageOptionsDto {}
