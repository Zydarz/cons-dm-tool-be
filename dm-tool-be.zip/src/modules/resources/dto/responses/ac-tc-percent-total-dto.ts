export class AcAndTcPercentTotalDto {
  acPercentTotal: number;
  tcPercentTotal: number;
}
