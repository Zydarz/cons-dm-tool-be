export interface DetailMemberRs {
  startDate?: Date;
  endDate?: Date;
  acPercent?: number;
  tcPercent?: number;
  positionId: number;
  userId: string;
  projectId: number;
}
