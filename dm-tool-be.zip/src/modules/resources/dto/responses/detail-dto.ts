export interface Detail {
  acPercent: number;
  tcPercent: number;
  start: number;
  end: number;
}
