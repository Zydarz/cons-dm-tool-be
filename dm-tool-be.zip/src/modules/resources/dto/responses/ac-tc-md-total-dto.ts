export class AcTcMdPercentTotalDto {
  acPercent: number;
  tcPercent: number;
  acPercentTotal: number;
  tcPercentTotal: number;
  totalMD: number;
}
