export namespace ProjectSituationNS {
  export enum Type {
    MONTH = 'month',
    YEAR = 'year',
    PROJECTID = 'projectId',
  }
}
