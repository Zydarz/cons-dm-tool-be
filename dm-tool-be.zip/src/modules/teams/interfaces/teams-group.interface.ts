export interface ITeamsGroup {
  id: string;
  displayName: string;
  description: string;
}
