export interface ITeamsChannel {
  id: string;
  displayName: string;
  description: string;
  webUrl: string;
}
