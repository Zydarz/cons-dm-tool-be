export interface ITeamsMember {
  userId: string;
  email: string;
  displayName: string;
}
