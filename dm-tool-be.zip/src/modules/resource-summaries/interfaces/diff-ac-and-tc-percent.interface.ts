export type DiffAcAndTcPercentInterface = Record<string, { acPercentDiff: number; tcPercentDiff: number }>;
