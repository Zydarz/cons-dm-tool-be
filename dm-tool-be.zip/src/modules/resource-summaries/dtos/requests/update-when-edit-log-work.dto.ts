export class UpdateResourceSummaryWhenEditLogworkDto {
  reportDateBefore?: Date;

  reportDateAfter?: Date;

  actualEffortBefore: number;

  actualEffortAfter: number;

  projectId: number;
}
