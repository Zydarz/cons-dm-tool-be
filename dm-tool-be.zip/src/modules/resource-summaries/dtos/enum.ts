export enum UpdateResourceSummaryType {
  ADD = 'add',
  SUBTRACT = 'subtract',
}
