'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await Promise.all([
      queryInterface.addColumn('department', 'flag_protected', {
        type: Sequelize.TINYINT,
        allowNull: false,
        default: 0,
        after: 'name'
      }),
    ])
  },

  async down (queryInterface, Sequelize) {
    await Promise.all([
      queryInterface.removeColumn('department', 'flag_protected'),
    ])
  }
};
