'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.sequelize.query(
        `ALTER TABLE project_situation_histories
        MODIFY COLUMN note text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL AFTER projectId;`
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
